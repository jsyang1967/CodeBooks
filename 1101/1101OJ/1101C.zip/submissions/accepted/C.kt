fun main() = println((1..9).map{readLine()!!}.sorted()[4])
