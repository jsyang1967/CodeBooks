print(input()[0:0]+'%d'%len(set(input().split())))
