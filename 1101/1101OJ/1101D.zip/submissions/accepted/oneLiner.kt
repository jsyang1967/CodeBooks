fun main(){readLine()?.also{println(readLine()!!.split(" ").distinct().size)}}
