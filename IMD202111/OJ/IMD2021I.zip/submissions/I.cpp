#include <iostream>
using namespace std;
 
int main() {
    int num, n, cnt;
    long long ans;
    string s;
    cin >> num;
    while (num--){
        cin >> n;
        cin >> s;
        cnt = 0; // 連續「>」個數
        ans = 0; // 累計最少逆序數對
        for (int i = 0; i < n-1; i++){
            if (s[i] == '>'){
                cnt++;
                ans += cnt;
            }else{
                cnt = 0;
            }
        }
        cout << ans << "\n";
    }
}